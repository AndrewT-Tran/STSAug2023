package com.andrew.abstractart;

public abstract class Art {
    protected String title;
    protected String author;
    protected String description;

    public abstract void viewArt();
}